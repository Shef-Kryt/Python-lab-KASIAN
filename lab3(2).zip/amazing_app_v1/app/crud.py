from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import Session
from typing import Optional
from app import models
from app import schemes
import hashlib
def create_database(engine_url: str) -> Session:
    try:
        engine = create_engine(engine_url)
        models.Base.metadata.create_all(bind=engine)
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        return SessionLocal()
    except Exception as e:
        print(f"An error occurred while creating the database: {e}")
        raise
def create_user(db: Session, user: schemes.UserCreate) -> models.User:
    try:
        hashed_password = hashlib.md5(user.password.encode())
        db_user = models.User(email=user.email, first_name=user.first_name,
                              second_name=user.second_name, password=hashed_password.hexdigest())
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        return db_user
    except Exception as e:
        print(f" creating the user: {e}")
        db.rollback()
        raise
def create_user_record(db: Session, item: schemes.RecordCreate, user_id: int) -> models.Record:
    try:
        db_record = models.Record(**item.dict(), user_id=user_id)
        db.add(db_record)
        db.commit()
        db.refresh(db_record)
        return db_record
    except Exception as e:
        print(f"creating the user record: {e}")
        db.rollback()
        raise
def get_user_by_email(db: Session, email: str) -> Optional[models.User]:
    try:
        return db.query(models.User).filter(models.User.email == email).first()
    except Exception as e:
        print(f"error  the user  email: {e}")
        raise
def update_user(db: Session, user_id: int, user_update: schemes.UserUpdate) -> models.User:
    try:
        db_user = db.query(models.User).filter(models.User.id == user_id).first()
        if db_user:
            for key, value in user_update.dict().items():
                setattr(db_user, key, value)
            db.commit()
            db.refresh(db_user)
            return db_user
        else:
            raise HTTPException(status_code=404, detail="User not found")
    except Exception as e:
        print(f"Error updating the user: {e}")
        db.rollback()
        raise
def delete_user(db: Session, user_id: int) -> models.User:
    try:
        db_user = db.query(models.User).filter(models.User.id == user_id).first()
        if db_user:
            db.delete(db_user)
            db.commit()
            return db_user
        else:
            raise HTTPException(status_code=404, detail="User not found")
    except Exception as e:
        print(f"Error deleting the user: {e}")
        db.rollback()
        raise

